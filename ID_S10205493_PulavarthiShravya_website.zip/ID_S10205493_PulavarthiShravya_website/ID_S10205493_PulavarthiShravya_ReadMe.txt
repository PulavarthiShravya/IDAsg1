Live Lively Band

My project is about a fictional band called live lively. Lively lively is a fictional that was formed in the year 2011. In my project I have added the names of my fictional players and more about them. Despite having difficulties initially I managed to come up with a scroll website consisting of 3 pages.

Design process

This website consists of mainly 3 pages. The first page is about the band. They include details of every band member and more about them. The second page is where the user is able to purchase merchandise of the band. There are mainly 3 merchandise. The band poster, tickets and a band t-shirt. The last page is where fans can contact the band by submitting a form or follow them on social media sites such as Instagram, Facebook or Twitter.

My audience for the website is for Live Lively fans. This website allows fans to keep in touch with the band through purchase of merchandise and even the various social media platforms. The website is catered for fans and the band themself to keep in touch with their listeners.

The sources I used to create my website is mainly w3schools.com

Features 

My website has a feature where one is able to have a smooth scroll and when hovering any one of the 5 band members' names, information about them appears.

The technology used to create my website is Adobe Xd where I came up with my wireframe.

Testing 
When a fan tries to submit a form, the form will not be submitted unless he/she enters a valid username.

Credits 
w3schools.com google images